# DANAT SHOP — o'yin to'ldirish boti + Mini App

Bitta fayl: `main.py` (bot + Flask Mini App + SQLite + admin panel).

## 1. GitHub
Ushbu 6 ta faylni repo'ga yuklang: `main.py`, `requirements.txt`, `Procfile`, `render.yaml`, `.gitignore`, `README.md`.

## 2. Render.com
- New → Web Service → repo'ni ulang
- Build: `pip install -r requirements.txt`
- Start: `python main.py`
- Environment:

| Key | Value |
|---|---|
| `BOT_TOKEN` | @BotFather tokeni |
| `ADMINS` | `7849637859` (vergul bilan bir nechta) |
| `WEBAPP_URL` | `https://danat-shop.onrender.com` (deploy tugagach) |

⚠️ Birinchi deploy'dan keyin URL paydo bo'ladi — uni `WEBAPP_URL` ga yozib qayta deploy qiling.

## 3. BotFather
- `/setmenubutton` → bot → URL: `WEBAPP_URL` → nomi: `Do'kon`
- `/setdomain` (agar so'rasa) → domen

## 4. Admin panel — `/admin`
- 📊 Statistika
- 🎮 O'yinlar: qo'shish / o'chirish / yoqish / rasm / nom / birlik / ID hint
- 📦 Paketlar: **narx**, eski narx, nom, yoqish/o'chirish, qo'shish, o'chirish
- 💳 **Karta**: UZCARD va HUMO raqamini istalgan vaqtda almashtirish
- 📢 **Majburiy obuna**: kanal qo'shish / o'chirish (bot kanalda admin bo'lishi shart)
- 👤 **Balans +/-**: `user_id | 50000` yoki `user_id | -50000`
- 🎟 Promokod: `KOD | summa | limit`
- 🧾 Buyurtmalar: ✅ bajarildi / ❌ rad etish (avtomatik pul qaytadi)
- 💰 To'ldirishlar: chekni tasdiqlash → balans avtomatik ortadi
- 👥 Foydalanuvchilar: qidirish, ban/unban
- 📣 Reklama: hammaga matn yoki rasm
- ⚙️ Sozlamalar: do'kon nomi, min. summa, referal bonus, support, banner

## To'lov oqimi
1. Foydalanuvchi ilovada summa + karta turini tanlaydi
2. Bot kartani va aniq summani yuboradi
3. Foydalanuvchi chek skrinshotini **botga rasm qilib** yuboradi
4. Admin ✅ bosadi → balans avtomatik to'ladi

## Eslatma
Render free plan uxlab qoladi — `https://SIZNING-URL/health` ni UptimeRobot bilan 5 daqiqada bir tekshirtiring.
